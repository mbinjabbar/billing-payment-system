import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class VisitService {
  private apiUrl = 'http://localhost:8000/api';
  private http   = inject(HttpClient);

  getVisits(page: number = 1, filters: any = {}) {
    return this.http.get(`${this.apiUrl}/visits`, {
      params: { ...filters, page }
    });
  }

  getVisitById(visitId: number) {
    return this.http.get(`${this.apiUrl}/visits/${visitId}`);
  }
}